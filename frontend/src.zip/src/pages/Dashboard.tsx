export default function Dashboard() {
  return (
    <div
      style={{
        display: "flex",
        height: "100vh",
        background: "#0B1220",
        color: "white",
      }}
    >
      <aside
        style={{
          width: "260px",
          background: "#111827",
          padding: "20px",
        }}
      >
        <h2>MAHI AI STUDIO</h2>

        <hr />

        <p>🏠 Dashboard</p>
        <p>🎬 Video Editor</p>
        <p>💬 Captions</p>
        <p>🎨 Effects</p>
        <p>🖼 Images</p>
        <p>📤 Export</p>
        <p>⚙ Settings</p>
      </aside>

      <main style={{ flex: 1, padding: "30px" }}>
        <h1>Dashboard</h1>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3,1fr)",
            gap: "20px",
            marginTop: "30px",
          }}
        >
          <div style={{ background: "#1F2937", padding: "20px", borderRadius: "12px" }}>
            Recent Projects
          </div>

          <div style={{ background: "#1F2937", padding: "20px", borderRadius: "12px" }}>
            AI Assistant
          </div>

          <div style={{ background: "#1F2937", padding: "20px", borderRadius: "12px" }}>
            System Status
          </div>
        </div>
      </main>
    </div>
  );
}